CREATE TABLE movie_table(
   id            INTEGER  NOT NULL PRIMARY KEY 
  ,movie_title   VARCHAR(21) NOT NULL
  ,month_playing INTEGER  NOT NULL
  ,theater_id    INTEGER  NOT NULL
);
INSERT INTO movie_table(id,movie_title,month_playing,theater_id) VALUES (1,'2001: a space odyssey',1,1);
INSERT INTO movie_table(id,movie_title,month_playing,theater_id) VALUES (2,'aliens',2,2);
INSERT INTO movie_table(id,movie_title,month_playing,theater_id) VALUES (3,'casablanca',3,3);
INSERT INTO movie_table(id,movie_title,month_playing,theater_id) VALUES (4,'blade runner',4,4);
INSERT INTO movie_table(id,movie_title,month_playing,theater_id) VALUES (5,'amadeus',5,5);
INSERT INTO movie_table(id,movie_title,month_playing,theater_id) VALUES (6,'8mm',6,6);
INSERT INTO movie_table(id,movie_title,month_playing,theater_id) VALUES (7,'barry lyndon',7,1);
INSERT INTO movie_table(id,movie_title,month_playing,theater_id) VALUES (8,'affliction',8,2);
INSERT INTO movie_table(id,movie_title,month_playing,theater_id) VALUES (9,'basic',9,3); 
INSERT INTO movie_table(id,movie_title,month_playing,theater_id) VALUES (10,'confidence'INSERT INTO movie_table(id,movie_title,month_playing,theater_id) VALUES (20,'8mm',2,2);